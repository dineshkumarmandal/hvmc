<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

ini_set('error_reporting', E_STRICT);

/**
 * Description of signin
 *
 * @author Mandal Dinesh
 */
class Employee_c extends MY_Controller {

    function __construct() {
        parent::__construct();
        $this->load->model('Employee_model');
    }

    function index() {
        $data['title'] = 'List'; 

             $data['EmployeeResult']=$this->Employee_model->EmployeeData();
            $this->load->view('employeelist', $data);
         
    }


    public function loadData(){

        $page = isset($_POST['page'])?$_POST['page']:1; 
            $limit = isset($_POST['rows'])?$_POST['rows']:10; 
            $sidx = isset($_POST['sidx'])?$_POST['sidx']:'name'; 
            $sord = isset($_POST['sord'])?$_POST['sord']:'';         
            $start = $limit*$page - $limit; 
            $start = ($start<0)?0:$start; 

            $where = ""; 
            $searchField = isset($_POST['searchField']) ? $_POST['searchField'] : false;
            $searchOper = isset($_POST['searchOper']) ? $_POST['searchOper']: false;
            $searchString = isset($_POST['searchString']) ? $_POST['searchString'] : false;

            if ($_POST['_search'] == 'true') {
        $ops = array(
        'eq'=>'=', 
        'ne'=>'<>',
        'lt'=>'<', 
        'le'=>'<=',
        'gt'=>'>', 
        'ge'=>'>=',
        'bw'=>'LIKE',
        'bn'=>'NOT LIKE',
        'in'=>'LIKE', 
        'ni'=>'NOT LIKE', 
        'ew'=>'LIKE', 
        'en'=>'NOT LIKE', 
        'cn'=>'LIKE', 
        'nc'=>'NOT LIKE' 
        );
        foreach ($ops as $key=>$value){
            if ($searchOper==$key) {
                $ops = $value;
            }
        }
        if($searchOper == 'eq' ) $searchString = $searchString;
        if($searchOper == 'bw' || $searchOper == 'bn') $searchString .= '%';
        if($searchOper == 'ew' || $searchOper == 'en' ) $searchString = '%'.$searchString;
        if($searchOper == 'cn' || $searchOper == 'nc' || $searchOper == 'in' || $searchOper == 'ni') $searchString = '%'.$searchString.'%';

        $where = "$searchField $ops '$searchString' "; 

    }

    if(!$sidx) 
        $sidx =1;
    $count = $this->db->count_all_results('table_5'); 
    if( $count > 0 ) {
        $total_pages = ceil($count/$limit);    
    } else {
        $total_pages = 0;
    }



    if ($page > $total_pages) 
        $page=$total_pages;


    $responce=null;
    $query = $this->Employee_model->getAllData($start,$limit,$sidx,$sord,$where); 
    $responce->page = $page;
    $responce->total = $total_pages;
    $responce->records = $count;
    $i=0;
    foreach($query as $row) {
        $responce->rows[$i]['id']=$row->id;
        $responce->rows[$i]['cell']=array($row->name,$row->email,$row->passport,$row->phone,$row->fax,$row->address);
        $i++;
    }

    echo json_encode($responce);
}


public function EditData(){

    $id=$this->input->post('id');
    $name=$this->input->post('name');
    $email=$this->input->post('email');
    $passport=$this->input->post('passport');
    $phone=$this->input->post('phone');
    $fax=$this->input->post('fax');
    $address=$this->input->post('address');
    $act=$this->input->post('act');

    $ar=$this->Employee_model->UpdateData('table_5', array('name'=>$name, 'email'=>$email, 'passport'=>$passport, 'phone'=>$phone, 'fax'=>$fax, 'address'=>$address), array('id'=>$id));
    $responce=null;
    $responce->affected_rows = $ar;    
    echo json_encode($responce);

 
}
 

    

     

}

/* End of file Signin.php */
/* Location: ./application/modules/EmployeeList/controllers/EmployeeList.php */