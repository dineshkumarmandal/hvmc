<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

/**
 * Description of signin
 *
 * @author Mandal Dinesh
 */
class Signin extends MY_Controller {

    function __construct() {
        parent::__construct();
        $this->load->library('form_validation');
        $this->load->model('Signin_model');
    }

    function index() {
        $data['title'] = 'Signin';

        $this->form_validation->set_rules('username', 'Username', 'required');
        $this->form_validation->set_rules('password', 'Password', 'required');

        if ($this->form_validation->run() === FALSE) {
            $this->load->view('signin', $data);
        } else {
            redirect();
        }
    }

    public function LoginCreditional()
    {
        $data['title'] = 'Signin';

        $username=$this->input->post('username');
        $password=$this->input->post('password');

        $this->form_validation->set_rules('username', 'Username', 'required');
        $this->form_validation->set_rules('password', 'Password', 'required');

        if ($this->form_validation->run() === FALSE) {
            $this->load->view('signin', $data);
        } else {

            $cond=array('USER_NAME'=>$username, 'USER_PASS'=>md5($password), 'STATUS'=>'0');
            $loginData=$this->Signin_model->LoginCreditional('mLogin', $cond)->row();
            var_dump($loginData); die();

            redirect();
        }

    }

}

/* End of file Signin.php */
/* Location: ./application/modules/signin/controllers/Signin.php */