<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

/**
 * Description of signin
 *
 * @author Mandal Dinesh
 */
class Employee extends MY_Controller {

    function __construct() {
        parent::__construct();
        $this->load->library('form_validation');
        $this->load->model('Employee_model');
        $this->load->helper('email');
    }

    function index() {
        $data['title'] = 'EMPLOYEE REGISTRATION';

         
            $this->load->view('employee', $data);
         
    }

    public function InsertEmployee()
    {
        $data['title'] = 'EMPLOYEE REGISTRATION';
  
        $returnBrowser=$this->Employee_model->getBrowser();
        $browser_name=$returnBrowser['name'].' '.$returnBrowser['version'];


        $name=$this->input->post('name');        
        $username=$this->input->post('username');
        $password=$this->input->post('password');
        $fname=$this->input->post('fname');
        $mname=$this->input->post('mname');
        $age=$this->input->post('age');
        $gender=$this->input->post('gender');
        $paddress=$this->input->post('paddress');
        $taddress=$this->input->post('taddress');
        $mobile=$this->input->post('mobile');
        $altmobile=$this->input->post('altmobile');
        $email=$this->input->post('email');
        $pan=$this->input->post('pan');
        $aadhar=$this->input->post('aadhar');


        $this->form_validation->set_rules('name', 'Name', 'required');   
        $this->form_validation->set_rules('email', 'Email', 'trim|required|valid_email');      

        if ($this->form_validation->run() === FALSE) {
            $this->load->view('employee', $data);
        } else {

            $initialName=$this->Employee_model->getInitials($name);
            $CODE=$initialName.''.date('His');

            $check=$this->Employee_model->CheckUsernameDublicate($username);
           

            if($check=='false')
            {

                $arrData=array(
                    'NAME'=>$name,
                    'CODE'=>$CODE,
                    'CREATED_ON'=>date('Y-m-d H:i:s'),
                    'BROWSER_NAME'=>$browser_name,
                );

                $ID_1=$this->Employee_model->InsertDataReturnID('table_1', $arrData);
                 
                 if($ID_1!=null)
                 {
                       $arrData=array(
                            'PARENT_ID'=>$ID_1,
                            'USER_NAME'=>$username,
                            'USER_PASS'=>$password,
                        );

                       $this->Employee_model->InsertData('mLogin', $arrData);


                       $arrData=array(
                            'PARENT_ID'=>$ID_1,
                            'FATHER_NAME'=>$fname,
                            'MOTHER_NAME'=>$mname,
                        );

                       $this->Employee_model->InsertData('table_2', $arrData);


                       $arrData=array(
                            'PARENT_ID'=>$ID_1,
                            'AGE'=>$age,
                            'JOINING_DATE'=>date('Y-m-d H:i:s'),
                            'PERMANENT_ADDRESS'=>$paddress,
                            'TEMPORARY_ADDRESS'=>$taddress,
                            'GENDER'=>$gender,
                            'EMAIL'=>$email,
                            'MOBILE'=>$mobile,
                            'ALTERNATE_MOBILE'=>$altmobile,
                            'PAN'=>$pan,
                            'AADHAR'=>$aadhar,
                        );

                       $this->Employee_model->InsertData('table_3', $arrData);

                 } // check ID null or not

            }
            else
            {

              $arrData=array(
                            'STATUS'=>'Failed',
                            'MESSAGE'=>'Username already exists !',
                            'NAME'=>$name,
                            'USER_NAME'=>$username,
                            'USER_PASS'=>$password,
                            'FATHER_NAME'=>$fname,
                            'MOTHER_NAME'=>$mname,
                            'AGE'=>$age,
                            'PERMANENT_ADDRESS'=>$paddress,
                            'TEMPORARY_ADDRESS'=>$taddress,
                            'GENDER'=>$gender,
                            'EMAIL'=>$email,
                            'MOBILE'=>$mobile,
                            'ALTERNATE_MOBILE'=>$altmobile,
                            'PAN'=>$pan,
                            'AADHAR'=>$aadhar,
                           );

              $data['SingleData']=$arrData;
               $this->load->view('employee', $data);  
            }
            


            redirect('site');
        }

    }

}

/* End of file Signin.php */
/* Location: ./application/modules/signin/controllers/Signin.php */