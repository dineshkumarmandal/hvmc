<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <title><?php echo $title; ?></title>

        <style type="text/css">

            ::selection { background-color: #E13300; color: white; }
            ::-moz-selection { background-color: #E13300; color: white; }

            body {
                background-color: #fff;
                margin: 40px;
                font: 13px/20px normal Helvetica, Arial, sans-serif;
                color: #4F5155;
            }

            a {
                color: #003399;
                background-color: transparent;
                font-weight: normal;
            }

            h1 {
                color: #444;
                background-color: transparent;
                border-bottom: 1px solid #D0D0D0;
                font-size: 19px;
                font-weight: normal;
                margin: 0 0 14px 0;
                padding: 14px 15px 10px 15px;
            }

            code {
                font-family: Consolas, Monaco, Courier New, Courier, monospace;
                font-size: 12px;
                background-color: #f9f9f9;
                border: 1px solid #D0D0D0;
                color: #002166;
                display: block;
                margin: 14px 0 14px 0;
                padding: 12px 10px 12px 10px;
            }

            #body {
                margin: 0 15px 0 15px;
            }

            #container {
                margin: 10px;
                border: 1px solid #D0D0D0;
                box-shadow: 0 0 8px #D0D0D0;
            }
        </style>

        
        <link href="https://cdn.datatables.net/1.10.19/css/jquery.dataTables.min.css" rel="stylesheet">  
        <script src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script> 

        

         <!-- DataTables CSS -->
        <!-- <link href="css/addons/datatables.min.css" rel="stylesheet"> -->
        <!-- DataTables JS -->
        <!-- <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script> -->
        <!-- <script href="https://code.jquery.com/jquery-3.3.1.js" rel="stylesheet"></script>   -->      
        <!-- DataTables Select JS -->
        <!-- <script href="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js" rel="stylesheet"></script>
        <script href="https://cdn.datatables.net/1.10.19/js/dataTables.bootstrap4.min.js" rel="stylesheet"></script> -->
        

        <script type="text/javascript">
           $(document).ready( function () {
                    $('#myTable').DataTable();
                } );
        </script>

        


    </head>
    <body>
        <div id="container">
            <h1>Signin Here!</h1>
            <div id="body">				 
				
				<p><?php echo anchor('site', 'Home', 'title="Go back Home"'); ?></p>

                <table id="myTable" class="table" cellspacing="0" width="100%">
          <thead>
            <tr>
                 <th class="th-sm">JOINING DATE
              </th>
              <th class="th-sm">NAME
              </th>
              <th class="th-sm">CODE
              </th>
              <th class="th-sm">USER NAME
              </th>
              <th class="th-sm">PASSWORD
              </th>
              <th class="th-sm">FATHER NAME
              </th>
              <th class="th-sm">MOTHER NAME
              </th>
              <th class="th-sm">AGE
              </th>
              <th class="th-sm">GENDER
              </th>
              <th class="th-sm">MOBILE
              </th>
              <th class="th-sm">ALT. MOBILE
              </th>
              <th class="th-sm">EMAIL
              </th>
              <th class="th-sm">PAN
              </th>
              <th class="th-sm">AADHAR
              </th>
              
              <th class="th-sm">PERMANENT ADDRESS
              </th>
              <th class="th-sm">TEMPORARY ADDRESS
              </th>
              <th class="th-sm">ACTION
              </th>
            </tr>
          </thead>
          <tbody>
            <?php

            if($EmployeeResult!=null)
            {
                 foreach ($EmployeeResult as $key) {

                    $JoiningDate=date('d-M-Y', strtotime($key['JOINING_DATE']));
                     ?>
                     <tr>
                        <td><?=$JoiningDate;?></td>
                         <td><?=$key['NAME'];?></td>
                         <td><?=$key['CODE'];?></td>
                         <td><?=$key['USER_NAME'];?></td>
                         <td><?=$key['USER_PASS'];?></td>
                         <td><?=$key['FATHER_NAME'];?></td>
                         <td><?=$key['MOTHER_NAME'];?></td>
                         <td><?=$key['AGE'];?></td>
                         <td><?=$key['GENDER'];?></td>
                         <td><?=$key['MOBILE'];?></td>
                         <td><?=$key['ALTERNATE_MOBILE'];?></td>
                         <td><?=$key['EMAIL'];?></td>
                         <td><?=$key['PAN'];?></td>
                         <td><?=$key['AADHAR'];?></td>
                         <td><?=$key['PERMANENT_ADDRESS'];?></td>
                         <td><?=$key['TEMPORARY_ADDRESS'];?></td>
                         <td>  <input type="button"   value="Edit" style="background-color: red; color:white;" id="<?=$key['ID'];?>" onclick="ButtonCLick(this.id);"/></td>
                     </tr>
                     <?php
                 }
            }

             ?>
          </tbody>
           
        </table>

        <br><br>
				
				<p class="footer">Page rendered in <strong>{elapsed_time}</strong> seconds. <?php echo (ENVIRONMENT === 'development') ? 'CodeIgniter Version <strong>' . CI_VERSION . '</strong>' : '' ?></p>
            </div>
        </div>
    </body>
    <script type="text/javascript">
        function ButtonCLick(ID)
        {

            var url="<?php echo 'EmployeeList/EmployeeList/EmployeeEdit' ?>"+"/"+ID;
            window.open(url, '_self');
             
        }
    </script>
</html>