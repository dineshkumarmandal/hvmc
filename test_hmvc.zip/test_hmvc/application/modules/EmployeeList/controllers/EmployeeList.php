<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

/**
 * Description of signin
 *
 * @author Mandal Dinesh
 */
class EmployeeList extends MY_Controller {

    function __construct() {
        parent::__construct();
        $this->load->model('Employee_model');
    }

    function index() {
        $data['title'] = 'List'; 

             $data['EmployeeResult']=$this->Employee_model->EmployeeData();
            $this->load->view('employeelist', $data);
         
    }

    public function EmployeeEdit($ID=null)
    {
        $data['title'] = 'EMPLOYEE REGISTRATION';
  
         if($ID!=null)
        {
            $data['SingleData']=$this->Employee_model->EmployeeDataSingle($ID);
           // var_dump($this->Employee_model->EmployeeDataSingle($ID)); die();
            $this->load->view('employee/employee', $data);
        }
        else
        {
            redirect('EmployeeList');
        }

 
        

    }

     

}

/* End of file Signin.php */
/* Location: ./application/modules/EmployeeList/controllers/EmployeeList.php */